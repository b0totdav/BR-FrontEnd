<template>
   <ul class="nav nav-pills">
  
  <li class="nav-item">
    <a class="nav-link" href="https://ikk.hu/osztondijak">Hivatlos tájékoztató az ösztöndíj mértékéről</a>
  </li>
  
</ul>
</template>