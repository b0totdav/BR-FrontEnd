<script setup>
  import axios from "axios";
  import {ref, onMounted} from 'vue'
  const tasks = ref([])

  onMounted(() =>{
    axios.get("http://localhost:3000/todos")
    .then(resp => {
      console.log(resp.data)
      tasks.value = resp.data
  })
  })
</script>

<template>
  <h1 class="text-center">Feladatok</h1>  
</template>
