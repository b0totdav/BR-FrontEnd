import { describe, it, expect, beforeEach } from 'vitest'

import { mount } from '@vue/test-utils'
import Calculator from '../Calculator.vue'
import { useCalculatorStore } from '@/stores/calculator'
import { createPinia, setActivePinia } from 'pinia'

describe('Számológép', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('Tartalom ellenőrzése', () => {
    const wrapper = mount(Calculator)
    expect(wrapper.text()).toContain('Számológép')
  })

  it('Kijelző kezdetben 0', () =>{
    const calc = useCalculatorStore()
    expect(calc.display).toBe("0")
  })

  it('Jól számol?', () => {
    const calc = useCalculatorStore()
    calc.display = "3+3"
    calc.calculate()
    expect(calc.display).toBe("6")
  })
})
