<script setup>
import Calculator from './components/Calculator.vue'
</script>

<template>
  <Calculator />
</template>